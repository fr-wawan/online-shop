

<?php $__env->startSection('content'); ?>
<main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-300">
    <div class="container mx-auto px-6 py-8">

        <?php if(session('status')): ?>
        <div class="bg-green-500 p-3 rounded-md shadow-sm mt-3">
            <?php if(session('status')=='profile-information-updated'): ?>
            Profile has been updated.
            <?php endif; ?>
            <?php if(session('status')=='password-updated'): ?>
            Password has been updated.
            <?php endif; ?>
            <?php if(session('status')=='two-factor-authentication-disabled'): ?>
            Two factor authentication disabled.
            <?php endif; ?>
            <?php if(session('status')=='two-factor-authentication-enabled'): ?>
            Two factor authentication enabled.
            <?php endif; ?>
            <?php if(session('status')=='recovery-codes-generated'): ?>
            Recovery codes generated.
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-4">

            <div>
                <?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::twoFactorAuthentication())): ?>
                <div class="p-6 bg-white rounded-md shadow-md">
                    <h2 class="text-lg text-gray-700 font-semibold capitalize">TWO-FACTOR AUTHENTICATION</h2>
                    <hr class="mt-4">

                    <div class="mt-4">
                        <?php if(! auth()->user()->two_factor_secret): ?>
                        
                        <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>">
                            <?php echo csrf_field(); ?>

                            <button type="submit"
                                class="px-4 py-2 bg-gray-600 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">
                                Enable Two-Factor
                            </button>
                        </form>
                        <?php else: ?>
                        
                        <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit"
                                class="px-4 py-2 bg-red-600 text-gray-200 rounded-md hover:bg-red-900 focus:outline-none focus:bg-gray-700">
                                Disable Two-Factor
                            </button>
                        </form>

                        <?php if(session('status') == 'two-factor-authentication-enabled'): ?>
                        
                        <div class="mt-4">
                            Otentikasi dua faktor sekarang diaktifkan. Pindai kode QR berikut menggunakan aplikasi
                            pengautentikasi ponsel Anda.
                        </div>

                        <div class="mb-3 mt-4">
                            <?php echo auth()->user()->twoFactorQrCodeSvg(); ?>

                        </div>
                        <?php endif; ?>

                        
                        <div class="mt-4">
                            Simpan recovery code ini dengan aman. Ini dapat digunakan untuk memulihkan akses ke akun
                            Anda jika perangkat otentikasi dua faktor Anda hilang.
                        </div>

                        <div style="background: rgb(44, 44, 44);color:white" class="rounded p-3 mb-2 mt-4">
                            <?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($code); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        
                        <form method="POST" action="<?php echo e(url('user/two-factor-recovery-codes')); ?>">
                            <?php echo csrf_field(); ?>

                            <button type="submit"
                                class="mt-4 px-4 py-2 bg-gray-600 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">
                                Regenerate Recovery Codes
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>

                </div>
                <?php endif; ?>
            </div>

            <div>
                <div class="p-6 bg-white rounded-md shadow-md">
                    <h2 class="text-lg text-gray-700 font-semibold capitalize">EDIT PROFILE</h2>
                    <hr class="mt-4">
                    <form class="mt-4" action="<?php echo e(route('user-profile-information.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label class="block">
                                <span class="text-gray-700 text-sm">Nama Lengkap</span>
                                <input type="text" name="name" value="<?php echo e(old('name') ?? auth()->user()->name); ?>"
                                    class="form-input mt-1 block w-full rounded-md" placeholder="Nama Lengkap">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div
                                    class="inline-flex max-w-sm w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                                    <div class="px-4 py-2">
                                        <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                                    </div>
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>
                        <div class="mt-4">
                            <label class="block">
                                <span class="text-gray-700 text-sm">Alamat Email</span>
                                <input type="email" name="email" value="<?php echo e(old('email') ?? auth()->user()->email); ?>"
                                    class="form-input mt-1 block w-full rounded-md" placeholder="Alamat Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div
                                    class="inline-flex max-w-sm w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                                    <div class="px-4 py-2">
                                        <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                                    </div>
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        </div>
                        <div class="flex justify-start mt-4">
                            <button type="submit"
                                class="px-4 py-2 bg-gray-600 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">UPDATE
                                PROFILE</button>
                        </div>
                    </form>
                </div>

                <div class="mt-6 p-6 bg-white rounded-md shadow-md">
                    <h2 class="text-lg text-gray-700 font-semibold capitalize">UPDATE PASSWORD</h2>
                    <hr class="mt-4">
                    <form class="mt-4" action="<?php echo e(route('user-password.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label class="block">
                                <span class="text-gray-700 text-sm">Password Lama</span>
                                <input type="password" name="current_password"
                                    class="form-input mt-1 block w-full rounded-md" placeholder="Password Lama">
                            </label>
                        </div>
                        <div class="mt-4">
                            <label class="block">
                                <span class="text-gray-700 text-sm">Password Baru</span>
                                <input type="password" name="password" class="form-input mt-1 block w-full rounded-md"
                                    placeholder="Password Baru">
                            </label>
                        </div>
                        <div class="mt-4">
                            <label class="block">
                                <span class="text-gray-700 text-sm">Konfirmasi Password Baru</span>
                                <input type="password" name="password_confirmation"
                                    class="form-input mt-1 block w-full rounded-md"
                                    placeholder="Konfirmasi Password Baru">
                            </label>
                        </div>
                        <div class="flex justify-start mt-4">
                            <button type="submit"
                                class="px-4 py-2 bg-gray-600 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">UPDATE
                                PASSWORD</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Profile - Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenov\online-shop\backend-shop\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>